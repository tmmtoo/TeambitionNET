@extends('layouts.errors')

@section('content')
<h2>Error</h2>
<h4>{{$message}}</h4>
@endsection
