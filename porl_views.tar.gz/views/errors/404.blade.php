@extends('layouts.errors')

@section('content')
<h1>404</h1>
<p>This page could not be found.</p>
@endsection
