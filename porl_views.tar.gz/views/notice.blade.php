@extends('layouts.base')

@section('content')
<h2>提 示</h2>
<h4>{{$message}}</h4>
@endsection
